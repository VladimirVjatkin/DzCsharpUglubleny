
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace _005dz
{
    internal class ServerSession
    {
        // Храним активные клиентские задачи и время их последней активности
        private static Dictionary<Task, DateTime> clientTasks = new Dictionary<Task, DateTime>();

        // Объект для блокировки потоков (синхронизация доступа к clientTasks)
        private static object lockObj = new object();

        // Флаг, определяющий работу сервера (true - сервер работает, false - сервер остановлен)
        private static bool isRunning = true;

        // Асинхронный метод, который запускает сервер и обрабатывает входящие UDP-сообщения
        public static async Task ServerAsync(string name)
        {
            // Создаем UDP клиент для прослушивания на порту 12345
            using (UdpClient udpClient = new UdpClient(12345))
            {
                // Создаем объект для хранения IP адреса клиента (удаленный конец)
                IPEndPoint remoteEndPoint = new IPEndPoint(IPAddress.Any, 0);

                Console.WriteLine("Server is running and waiting for messages...");

                // Запускаем мониторинг клиентских задач в отдельной задаче
                var monitorTask = MonitorClientTasks();

                try
                {
                    // Основной цикл работы сервера
                    while (isRunning) // Пока сервер работает
                    {
                        // Проверяем, есть ли входящие данные
                        if (udpClient.Available > 0)
                        {
                            // Асинхронно принимаем данные от клиента
                            UdpReceiveResult receiveResult = await udpClient.ReceiveAsync();
                            // Преобразуем байты в строку
                            string receivedData = Encoding.UTF8.GetString(receiveResult.Buffer);

                            // Обрабатываем сообщение клиента в отдельной задаче
                            var clientTask = HandleClientAsync(receivedData, receiveResult.RemoteEndPoint, udpClient);

                            // Добавляем задачу в список активных задач, используя блокировку для потокобезопасности
                            lock (lockObj)
                            {
                                clientTasks[clientTask] = DateTime.Now; // Сохраняем время последнего обращения клиента
                            }
                        }
                        else
                        {
                            // Если данных нет, делаем паузу, чтобы снизить нагрузку на процессор
                            await Task.Delay(100);
                        }
                    }
                }
                finally
                {
                    // Когда сервер останавливается, закрываем все задачи и останавливаем мониторинг
                    StopServer();
                    
                    await monitorTask; // Дожидаемся завершения мониторинга
                }
            }
        }

        // Метод для остановки сервера
        public static void StopServer()
        {
            // Устанавливаем флаг isRunning в false, что сигнализирует остановку сервера
            Console.WriteLine("Server stop");
            isRunning = false;
        }

        // Метод для обработки сообщений от клиента
        private static async Task HandleClientAsync(string message, IPEndPoint clientEndPoint, UdpClient udpClient)
        {
            // Выводим на экран сообщение от клиента
            Console.WriteLine($"Received message: {message}");

            // Формируем ответ сервер на сообщение клиента
            string response = $"Server response to {message}";

            // Преобразуем строку ответа в байты
            byte[] replyBytes = Encoding.UTF8.GetBytes(response);

            // Отправляем ответ клиенту
            await udpClient.SendAsync(replyBytes, replyBytes.Length, clientEndPoint);

            // После завершения задачи удаляем её из списка активных задач
            lock (lockObj)
            {
                // Ищем завершенные задачи в списке (например, если задача завершена)
                var taskToRemove = clientTasks.Keys.FirstOrDefault(t => t == Task.CompletedTask);

                // Если задача найдена и завершена, удаляем её из словаря
                if (taskToRemove != null)
                {
                    clientTasks.Remove(taskToRemove);
                    Console.WriteLine("Client task removed from active list.");
                }
            }
        }

        // Метод для мониторинга активности клиентских задач
        private static async Task MonitorClientTasks()
        {
            // Пока сервер работает
            while (isRunning)
            {
                // Используем блокировку для безопасного доступа к списку задач
                lock (lockObj)
                {
                    // Выводим количество активных задач
                    Console.WriteLine($"Active client tasks: {clientTasks.Count}");

                    // Перебираем все активные задачи и выводим информацию о них
                    foreach (var entry in clientTasks)
                    {
                        Console.WriteLine($"Task ID: {entry.Key.Id}, Last Used: {entry.Value}");
                    }
                }

                // Делаем паузу перед следующей проверкой (10 секунд)
                await Task.Delay(10000);
            }
        }
    }

}


/*
 
ServerAsync — это основной метод, который запускает сервер и отвечает за обработку входящих сообщений. 
Он использует асинхронные задачи для работы с клиентами.

MonitorClientTasks — это отдельная задача, которая мониторит список активных задач, чтобы знать, 
какие клиенты подключены, и сколько времени прошло с момента их последней активности.

HandleClientAsync — обрабатывает сообщения от клиента. После обработки, задача удаляется из списка активных.
Этот сервер основан на протоколе UDP, который не требует установления соединения,
а значит, сервер просто получает и обрабатывает сообщения по мере их поступления.

 */
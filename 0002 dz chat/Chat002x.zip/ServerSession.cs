﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Chat002x
{
    internal class ServerSession
    {
        public static void Server(string name)
        {
            UdpClient udpClient;
            IPEndPoint remoteEndPoint;
            udpClient = new UdpClient(12345);
            remoteEndPoint = new IPEndPoint(IPAddress.Any, 0);
            Console.WriteLine("Ser_UDP Client wait messages...");
            while (true)
            {
                byte[] receiveBytes = udpClient.Receive(ref remoteEndPoint);
                string receivedData = Encoding.UTF8.GetString(receiveBytes);
                try
                {
                    var message = Message.FromJson(receivedData);
                    Console.WriteLine($"Ser_Receive message from {message.FromName} ({message.Date}):");
                    Console.WriteLine(message.Text);
                    Console.Write("Type your answer and press Enter: ");
                    string replyMessage = Console.ReadLine();
                    var replyMessageJson = new Message()
                    {
                        Date = DateTime.Now,
                        FromName = name,
                        Text = replyMessage
                    }.ToJson();
                    byte[] replyBytes =
                    Encoding.ASCII.GetBytes(replyMessageJson);
                    udpClient.Send(replyBytes, replyBytes.Length,
                    remoteEndPoint);
                    Console.WriteLine("Response sent.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error during message processing: " +
                    ex.Message);
                }
            }
        }
    }
}

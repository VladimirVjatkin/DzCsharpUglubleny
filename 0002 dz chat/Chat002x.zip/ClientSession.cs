﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace Chat002x
{
    internal class ClientSession
    {
        public static void Client(string name, string ip)
        {
            UdpClient udpClient;
            IPEndPoint remoteEndPoint = new IPEndPoint(IPAddress.Parse(ip), 12345);
            udpClient = new UdpClient();
            // remoteEndPoint = new IPEndPoint(IPAddress.Parse(ip), 12345);

            while (true)
            {
                try
                {
                    Console.WriteLine("CL_UDP Client wait messages...");
                    Console.Write("CL_Type your answer and press Enter:  ");
                    string message = Console.ReadLine();
                    var messageJson = new Message()
                    {
                        Date = DateTime.Now,
                        FromName = name,
                        Text = message
                    }.ToJson();
                    byte[] replyBytes = Encoding.UTF8.GetBytes(messageJson);
                    udpClient.Send(replyBytes, replyBytes.Length,
                    remoteEndPoint);
                    Console.WriteLine("CL_Response sent.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine("CL_Error during message processing: " + ex.Message);
                }
                byte[] receiveBytes = udpClient.Receive(ref remoteEndPoint);
                string receivedData = Encoding.ASCII.GetString(receiveBytes);
                var messageReceived = Message.FromJson(receivedData);
                Console.WriteLine($"CL_Message received from {messageReceived.FromName} ({messageReceived.Date}):");
                Console.WriteLine(messageReceived.Text);

            }
        }
    }
}
